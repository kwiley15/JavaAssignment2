package com.example.JavaAssignmentManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaAssignmentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaAssignmentManagementApplication.class, args);
	}

}
