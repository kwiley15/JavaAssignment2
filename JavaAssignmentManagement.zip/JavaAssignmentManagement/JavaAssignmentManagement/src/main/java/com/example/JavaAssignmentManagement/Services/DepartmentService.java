package com.example.JavaAssignmentManagement.Services;



import com.example.JavaAssignmentManagement.Models.Department;
import com.example.JavaAssignmentManagement.Repos.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DepartmentService {



    @Autowired
    private DepartmentRepo departmentRepo;

    public Department getDepartmentById(Long id) {
        Optional<Department> department = departmentRepo.findById(id);
        return department.orElseThrow(() -> new RuntimeException("Department not found"));
    }

}
