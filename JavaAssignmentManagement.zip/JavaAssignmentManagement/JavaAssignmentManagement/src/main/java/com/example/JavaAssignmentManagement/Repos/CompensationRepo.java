package com.example.JavaAssignmentManagement.Repos;


import com.example.JavaAssignmentManagement.Models.Compensation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompensationRepo extends JpaRepository<Compensation, Long> {

}
