package com.example.JavaAssignmentManagement.Repos;

import com.example.JavaAssignmentManagement.Models.Worker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

@Repository
public interface WorkerRepo extends JpaRepository<Worker, Long> {

    Worker findTopByOrderByIdDesc();

}
