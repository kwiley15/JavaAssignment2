package com.example.JavaAssignmentManagement.Controllers;


import com.example.JavaAssignmentManagement.Models.Compensation;
import com.example.JavaAssignmentManagement.Models.Department;
import com.example.JavaAssignmentManagement.Models.Worker;
import com.example.JavaAssignmentManagement.Repos.CompensationRepo;
import com.example.JavaAssignmentManagement.Repos.DepartmentRepo;
import com.example.JavaAssignmentManagement.Repos.WorkerRepo;
import com.example.JavaAssignmentManagement.Services.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/worker")
public class WorkerController {

    @Autowired
    private WorkerRepo workerRepo;

    @Autowired
    private CompensationRepo compensationRepo;

    @Autowired
    private DepartmentService departmentService;

    private final DepartmentRepo departmentRepo;


    public WorkerController(DepartmentRepo departmentRepo) {
        this.departmentRepo = departmentRepo;
    }

    @GetMapping("/new")
    public String newWorkerForm(Model model) {
        if (departmentRepo.count() == 0) {
            departmentRepo.save(new Department("HR"));
            departmentRepo.save(new Department("Engineering"));
            departmentRepo.save(new Department("Marketing"));
        }

        model.addAttribute("worker", new Worker());
        model.addAttribute("departments", departmentRepo.findAll());
        return "create_worker";
    }

    @PostMapping
    public String createWorker(@ModelAttribute Worker worker, Model model) {
        if (worker.getRole() == null || worker.getDepartment() == null) {
            throw new IllegalArgumentException("Role and Department cannot be null");
        }

        Compensation compensation = new Compensation();
        switch (worker.getRole()) {
            case "Intern":
                compensation.setAmount(50000);
                break;
            case "Junior":
                compensation.setAmount(60000);
                break;
            case "Senior":
                compensation.setAmount(75000);
                break;
            case "Manager":
                compensation.setAmount(90000);
                break;
            case "Director":
                compensation.setAmount(120000);
                break;
            default:
                throw new IllegalArgumentException("Invalid role: " + worker.getRole());
        }

        compensationRepo.save(compensation);
        worker.setCompensation(compensation);

        // Retrieve and set department
        Department department = departmentService.getDepartmentById(worker.getDepartment().getId());
        worker.setDepartment(department);

        // Save worker first
        workerRepo.save(worker);

        // Retrieve the most recent entry
        Worker latestWorker = workerRepo.findTopByOrderByIdDesc();
        model.addAttribute("latestWorker", latestWorker);

        return "recently_added";
    }

    @GetMapping
    public String getAllWorkers(Model model) {
        model.addAttribute("Workers", workerRepo.findAll());
        return "worker_list";
    }

}
