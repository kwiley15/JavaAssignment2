package com.example.JavaAssignmentManagement.Models;

import jakarta.persistence.*;

@Entity
public class Worker {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String role;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    @OneToOne
    @JoinColumn(name = "compensation_id")
    private Compensation compensation;


    public Worker() {}

    public Worker(String name, String role, Department department, Compensation compensation) {
        this.name = name;
        this.role = role;
        this.department = department;
        this.compensation = compensation;
    }


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public Department getDepartment() { return department; }
    public void setDepartment(Department department) { this.department = department; }

    public Compensation getCompensation() { return compensation; }
    public void setCompensation(Compensation compensation) { this.compensation = compensation; }
}
